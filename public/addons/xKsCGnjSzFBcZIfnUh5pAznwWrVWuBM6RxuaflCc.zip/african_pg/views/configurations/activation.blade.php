@extends('backend.layouts.app')

@section('content')
    @if(addon_is_activated('african_pg'))
        <div class="row">
            @if(get_setting('mpesa') == 1)
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0 h6 text-center">{{translate('MPesa Activation')}}</h3>
                        </div>
                        <div class="card-body text-center">
                            <div class="clearfix">
                                <img class="float-left" src="{{ static_asset('assets/img/cards/mpesa.png') }}" height="30">
                                <label class="aiz-switch aiz-switch-success mb-0 float-right">
                                    <input type="checkbox" onchange="updateSettings(this, 'mpesa')" @if(get_setting('mpesa') == 1) checked @endif>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                            <div class="alert" style="color: #004085;background-color: #cce5ff;border-color: #b8daff;margin-bottom:0;margin-top:10px;">
                                {{ translate('You need to configure Mpesa correctly to enable this feature') }}. <a href="{{ route('payment_method.index') }}">{{ translate('Configure Now') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mb-0 h6 text-center">{{translate('flutterwave Activation')}}</h3>
                    </div>
                    <div class="card-body text-center">
                        <div class="clearfix">
                            <img class="float-left" src="{{ static_asset('assets/img/cards/flutterwave.png') }}" height="30">
                            <label class="aiz-switch aiz-switch-success mb-0 float-right">
                                <input type="checkbox" onchange="updateSettings(this, 'flutterwave')" @if(get_setting('flutterwave') == 1) checked @endif>
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <div class="alert" style="color: #004085;background-color: #cce5ff;border-color: #b8daff;margin-bottom:0;margin-top:10px;">
                            {{ translate('You need to configure flutterwave correctly to enable this feature') }}. <a href="{{ route('payment_method.index') }}">{{ translate('Configure Now') }}</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h3 class="mb-0 h6 text-center">{{translate('Payfast Activation')}}</h3>
                    </div>
                    <div class="card-body text-center">
                        <div class="clearfix">
                            <img class="float-left" src="{{ static_asset('assets/img/cards/payfast.png') }}" height="30">
                            <label class="aiz-switch aiz-switch-success mb-0 float-right">
                                <input type="checkbox" onchange="updateSettings(this, 'payfast')" @if(get_setting('payfast') == 1) checked @endif>
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <div class="alert" style="color: #004085;background-color: #cce5ff;border-color: #b8daff;margin-bottom:0;margin-top:10px;">
                            {{ translate('You need to configure payfast correctly to enable this feature') }}. <a href="{{ route('payment_method.index') }}">{{ translate('Configure Now') }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    @endsection

@section('script')
    <script type="text/javascript">
        function updateSettings(el, type){
            if($(el).is(':checked')){
                var value = 1;
            }
            else{
                var value = 0;
            }
            $.post('{{ route('business_settings.update.activation') }}', {_token:'{{ csrf_token() }}', type:type, value:value}, function(data){
                if(data == '1'){
                    AIZ.plugins.notify('success', 'Settings updated successfully');
                }
                else{
                    AIZ.plugins.notify('danger', 'Something went wrong');
                }
            });
        }
    </script>
@endsection
