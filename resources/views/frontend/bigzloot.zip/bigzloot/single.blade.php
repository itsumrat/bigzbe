@extends('frontend.layouts.app')

@section('customStyles')
<link rel="stylesheet" href="{{ static_asset('assets/css/custom-modified.css') }}">
@endsection 

@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-12">
    @if ($shop->sliders != null)
                        @foreach (explode(',',$shop->sliders) as $key => $slide)
                                <img class=" lazyload width="100%" height="500px"" src="{{ static_asset('assets/img/placeholder-rect.jpg') }}" data-src="{{ uploaded_asset($slide) }}" alt="{{ $key }} offer">
                        @endforeach
                    @endif
        </div>
    <div class="col-md-8">
      <h2>{{$shop->name}} <span>Health & Beauty</span></h2>
      <p>{{$shop->address}}</p>
      <p>Offer</p>
      Flat {{$shop->flat_discount}}% Off
    </div>
    <div class="col-md-4">
      <p>Contact: {{$shop->phone}}</p>
      <p>Openning Hour</p>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM <br>
        09:00 AM - 09:00 PM
    </div>
  </div>
</div>
@endsection 