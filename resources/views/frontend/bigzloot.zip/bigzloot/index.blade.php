@extends('frontend.layouts.app')

@section('customStyles')
<link rel="stylesheet" href="{{ static_asset('assets/css/custom-modified.css') }}">
@endsection 

@section('content')

<div class="container">
  <div class="row">


  @foreach($shops as $shop)
    <div class="col-md-6">
      <div class="shop-banner">
        <a href="{{ route('bzshop.visit', $shop->slug) }}" class="text-reset d-block">

        @if ($shop->sliders != null)
                        @foreach (explode(',',$shop->sliders) as $key => $slide)
                                <img class="d-block lazyload img-fit h-150px" src="{{ static_asset('assets/img/placeholder-rect.jpg') }}" data-src="{{ uploaded_asset($slide) }}" alt="{{ $key }} offer">
                        @endforeach
        @endif
        </a>
      </div>
      
      <div class="shop-logo">
        <a href="{{ route('bzshop.visit', $shop->slug)}}" class="text-reset">
        <img src="@if ($shop->logo !== null) {{ uploaded_asset($shop->logo) }} @else {{ static_asset('assets/img/placeholder.jpg') }} @endif" alt="{{ $shop->name }}" class="border rounded-circle shadow-2xl border-2 size-90px"></a>
      </div>
      <div class="shop-summary">
          <h4 class="shop-name">{{$shop->name}}</h4>
          <p>{{$shop->address}}</p>
      </div>
    </div>
  @endforeach
  </div>
</div>
@endsection